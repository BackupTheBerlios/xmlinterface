#include <iostream.h>

#include "vstdom.hpp"

int main( int argC, char *argV[])
{
  // vstdom mit xml file initiieren
  vstdom *testvstdom = new vstdom("xml/beispiel.xml");

  // xmlfile parsen lassen
  testvstdom->parse();

  // Anzahl der root Elemente bestimmen
  cout << endl << "Anzahl der root Widget " << testvstdom->getNumberOfChildWidget();  

  cout << endl << "Name vom root Widget " << (testvstdom->getNameOfRootWidget(0)).c_str();
  
  // Anzahl der ChildElemente
  cout << endl << (testvstdom->getNameOfRootWidget(0)).c_str()
               << " hat so viele Kinder " 
               << testvstdom->getNumberOfChildWidget("Fenster");

  // testvstdom->writexml("xml/neu.xml");

  delete testvstdom;

  cout << "\n" << flush;
  return 0;
}